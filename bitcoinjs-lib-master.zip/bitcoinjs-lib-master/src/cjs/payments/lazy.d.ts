export declare function prop(object: object, name: string, f: () => any): void;
export declare function value<T>(f: () => T): () => T;
