# LICENSE

Please see the license here: [https://github.com/SAWARATSUKI/KawaiiLogos/blob/main/README_EN.md](https://github.com/SAWARATSUKI/KawaiiLogos/blob/main/README_EN.md)
